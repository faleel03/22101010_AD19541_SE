import unittest
import numpy as np
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from app import recommend, fetch_data

class TestMovieRecommender(unittest.TestCase):

    def test_recommend(self):
        # Set up mock movie DataFrame and feature matrix for testing
        mock_movies = pd.DataFrame({"Title": ["Movie A", "Movie B", "Movie C", "Movie D", "Movie E"]})
        mock_features = np.array([[1, 0], [0, 1], [1, 1], [0, 0], [1, 0]])  # Convert to numpy array

        # Test recommendation with a valid movie
        recommendations = recommend("Movie A", mock_movies, mock_features)
        
        # Check that 'Movie B' is in the recommendations, regardless of the order
        self.assertTrue("Movie B" in recommendations.values)
        self.assertTrue("Movie C" in recommendations.values)



    def test_fetch_data(self):
        # Test with a truly nonexistent movie title
        movie_data = fetch_data("Nonexistent Movie XYZ")  # Unique title unlikely to match anything
        # Update to match the expected return format if movie not found
        self.assertEqual(movie_data, ('N/A', 'N/A', 'N/A', 'N/A', None))

    def test_fetch_data_existing_movie(self):
        # Test with a title that exists to ensure fetch_data returns expected data format
        movie_data = fetch_data("Movie A")  # Replace with an actual title in the dataset if available
        expected_data = ("2017", "James Rolfe", "James Rolfe", 
                         "Description of the movie", 
                         "https://example.com/image.jpg")  # Replace these with real or mock values
        self.assertIsInstance(movie_data, tuple)
        self.assertEqual(len(movie_data), 5)

# Run the tests
if __name__ == '__main__':
    unittest.main()
